/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hinhHoc;

/**
 *
 * @author Legion 5
 */
public class HinhHoc {
    
    // Phương thức tính diện tích (hình chữ nhật và hình vuông sẽ được cài đặt riêng)
    public double tinhDienTich() {
        return 0.0;
    }

    // Phương thức tính chu vi (hình chữ nhật và hình vuông sẽ được cài đặt riêng)
    public double tinhChuVi() {
        return 0.0;
    }

    // Phương thức hiển thị thông tin về các cạnh của hình (hình chữ nhật và hình vuông sẽ được cài đặt riêng)
    public void hienThiThongTin() {
    }
}

